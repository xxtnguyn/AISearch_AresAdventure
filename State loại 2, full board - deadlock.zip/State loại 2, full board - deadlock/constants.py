# Kí hiệu các vật thể trong trò chơi
WALL_CHAR = '#'
ARES_CHAR = '@'
ROCK_CHAR = '$'
GOAL_CHAR = '.'
ROCK_GOAL_CHAR = '*'
ARES_GOAL_CHAR = '+'
SPACE_CHAR = ' '

# Chuyển sang số
WALL_NUM = -1
ARES_NUM = -2
SPACE_NUM = 0

# Cost
WALK_COST = 0.001
